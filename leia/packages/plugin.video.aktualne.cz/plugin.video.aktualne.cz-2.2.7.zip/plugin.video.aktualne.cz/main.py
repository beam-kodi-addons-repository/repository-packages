from resources.lib import plugin

plugin.run()
